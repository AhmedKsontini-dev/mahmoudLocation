---
name: Mediterranean Mobility
colors:
  surface: '#f9f9ff'
  surface-dim: '#d1daf4'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8ff'
  surface-container-highest: '#d9e2fc'
  on-surface: '#121b2e'
  on-surface-variant: '#424752'
  inverse-surface: '#273044'
  inverse-on-surface: '#edf0ff'
  outline: '#737783'
  outline-variant: '#c3c6d3'
  surface-tint: '#245cb1'
  primary: '#00377a'
  on-primary: '#ffffff'
  primary-container: '#0b4ea2'
  on-primary-container: '#a8c4ff'
  inverse-primary: '#acc7ff'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#00432c'
  on-tertiary: '#ffffff'
  tertiary-container: '#005d3e'
  on-tertiary-container: '#4bdca0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#acc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004492'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f9f9ff'
  on-background: '#121b2e'
  surface-variant: '#d9e2fc'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  section-gap-sm: 2.5rem
  section-gap-md: 4rem
  section-gap-lg: 6rem
---

## Brand & Style

This design system delivers a refined, high-assurance travel mobility experience tailored for tourists, business travelers, and diaspora returning to Tunisia. The visual language conveys punctuality, executive safety, and effortless Mediterranean navigation. 

### Design Movement & Aesthetic
The system unites **Modern Corporate** reliability with airy, coastal **Minimalism**. Clean horizontal structure, crisp dividers, generous whitespace, and purposeful micro-interactions eliminate anxiety around car rentals, airport pickups, and intercity transit booking.

### Target Audience & Core Experience
- **Audience:** International holidaymakers, corporate executives, VIP airport arrivals, and private tour groups seeking verified, seamless transit throughout Tunisia (Tunis-Carthage, Enfidha, Djerba, Hammamet, Sousse, Tozeur).
- **Emotional Response:** Utmost peace of mind, premium reliability, Mediterranean freshness, and frictionless clarity.

## Colors

The color architecture is strictly grounded in deep maritime blues and crisp, luminous whites, evoking the Mediterranean coast of Sidi Bou Said and executive hospitality.

### Palette Architecture
- **Primary Navy (`#0B4EA2`):** Conveys stability and sovereign authority; reserved for primary actions, header branding, and selected state outlines.
- **Deep Navy (`#073B7A`):** Used for hover interactions on primary actions, high-emphasis icons, and footer backgrounds.
- **Accent Azure (`#0284C7`):** Highlights active paths, vehicle feature tags, interactive map markers, and secondary calls to action.
- **Light Blue (`#EAF4FF`):** Surface fill for interactive tints, vehicle category chips, active calendar cells, and feature callouts.
- **Success Emerald (`#10B981`):** Indicates instant booking confirmation, flight tracking status, "Free Cancellation", and verified driver badges.
- **Pure White (`#FFFFFF`):** Base canvas for elevated cards, modal sheets, and floating booking search bars.
- **Surface Background (`#F7FAFC`):** Soft, non-glare canvas behind card grids and checkout flows.
- **Crisp Border (`#E2E8F0`):** Precise 1px structural definition for cards, segment controls, and input strokes.
- **Text Primary (`#172033`):** High-contrast, near-black navy for headings, pricing numerals, and essential terms.
- **Text Secondary (`#667085`):** Balanced neutral for luggage limits, vehicle specifications, and transfer notes.

## Typography

Typographic scale is constructed entirely using **Plus Jakarta Sans**, offering a balance of clean geometric legibility and approachable curves.

### Type Hierarchy & Usage
- **Display & Large Headlines:** Used for primary landing value propositions, hero route finders, and VIP reservation headers. Always tight tracking (`-0.02em` to `-0.015em`) to retain visual authority.
- **Headlines & Titles:** Provide immediate orientation inside vehicle catalogs, terminal pickup instructions, and itinerary breakdowns.
- **Body:** Neutral `14px` and `16px` weights are strictly tuned for high readability across car specifications (manual/automatic, mileage, air conditioning) and cancellation policies.
- **Labels & Microcopy:** Badges, vehicle category tags ("SUV", "Executive Sedan", "Private Van"), and flight tracker statuses leverage uppercase or bold tabular alignments for immediate visual scanning.

## Layout & Spacing

A standard 8px baseline rhythm dictates all spacing increments, guaranteeing harmonious alignment across dynamic booking widgets and listing cards.

### Layout Philosophy
- **Fluid Multi-Column System:**
  - **Desktop (>= 1024px):** 12-column grid with a maximum content container of `1280px`. Gutters are fixed at `24px` (`1.5rem`) with `48px` outer margins.
  - **Tablet (768px – 1023px):** 8-column grid with `20px` gutters and `32px` outer margins.
  - **Mobile (< 768px):** 4-column fluid layout with `16px` gutters and `16px` outer horizontal padding.
- **Booking Engine Alignment:** The unified mobility selector (Car Rental, Airport VIP, City Transfer, Excursions) breaks outside the hero container on desktop as an overlapping card surface with 32px padding, anchoring user intent immediately above the fold.

## Elevation & Depth

Visual hierarchy is maintained through crisp structural borders (`#E2E8F0`) combined with soft, diffuse, Mediterranean navy-tinted ambient shadows. Avoid heavy, muddy dropshadows.

### Shadow Tiers
- **Flat Layer (`Elevation-0`):** Structural panels resting on `#F7FAFC` with a 1px solid `#E2E8F0` border.
- **Resting Card (`Elevation-1`):** Used for standard vehicle cards, tour packages, and airport pickup options.
  - `box-shadow: 0 1px 3px 0 rgba(11, 78, 162, 0.04), 0 1px 2px -1px rgba(11, 78, 162, 0.04);`
  - Border: 1px solid `#E2E8F0`.
- **Raised Interactive / Hover (`Elevation-2`):** Activated when hovering vehicle cards or interacting with dropdown menus.
  - `box-shadow: 0 10px 25px -5px rgba(11, 78, 162, 0.08), 0 8px 10px -6px rgba(11, 78, 162, 0.04);`
  - Border: 1px solid `#0284C7` (on hover) or `#E2E8F0`.
- **Floating Modals & Search Header (`Elevation-3`):** Reserved for booking bar overlays, VIP driver live-tracking drawers, and checkout drawers.
  - `box-shadow: 0 20px 30px -10px rgba(7, 59, 122, 0.12), 0 10px 15px -5px rgba(7, 59, 122, 0.06);`
  - Border: 1px solid `#E2E8F0`.

## Shapes

The design uses a clean, contemporary border radius range of **12px to 16px** for cards and interactive inputs, alongside **full pill shapes (9999px)** for tags, filter chips, and primary booking triggers.

### Shape Geometry
- **Vehicle & Tour Cards:** `16px` (`rounded-xl`) corner radius creates a modern, trustworthy framing.
- **Form Controls & Date Pickers:** `12px` (`rounded-lg`) corner radius for high touch comfort.
- **Badges, Filters & Floating Indicators:** Fully rounded (`rounded-full`, 9999px) pills for ease of status identification ("Automatic", "VIP Fast Track", "Includes Chauffeur").

## Components

### Buttons
- **Primary Action:** Solid `#0B4EA2` with `#FFFFFF` text, `12px` or pill radius, min-height `48px` (mobile `52px` for tap target safety). On hover: `#073B7A` with subtle upward transform (`translate-y: -1px`).
- **Secondary Action:** Outlined with 1.5px `#0B4EA2`, white background, `#0B4EA2` text. Hover transitions to `#EAF4FF`.
- **Tertiary / Utility:** Neutral text `#172033` with `#F7FAFC` background; hover `#EAF4FF` with `#0284C7` text.

### Vehicle & Route Cards
- Built on `#FFFFFF` background with `16px` radius, `1px solid #E2E8F0`, and `Elevation-1`.
- Contains:
  - High-resolution vehicle image on clean neutral surface.
  - Category pill badge top-left (`#EAF4FF` fill, `#0B4EA2` label).
  - Spec bar with icons: Passengers, luggage count, transmission type, A/C.
  - Dedicated pricing stack: Bold, large text `#172033` (e.g., "140 TND / day"), with conversion estimate and clear "Taxes & insurance included" subtext in `#667085`.

### Chips & Filters
- Inactive: Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#667085`.
- Active: Background `#EAF4FF`, border `1px solid #0284C7`, text `#0B4EA2` with a leading checkmark icon.

### Form Inputs & Dropdowns
- Minimum height `48px`, `12px` radius, border `1px solid #E2E8F0`, background `#FFFFFF`.
- Focus state: Border color changes to `#0B4EA2` with a 3px outer ring of `#EAF4FF` (`rgba(11, 78, 162, 0.15)`).
- Clear input icons for pickup location (e.g., "TUN - Tunis-Carthage Airport"), drop-off terminal, dates, and flight number tracking.

### Checkboxes & Radios
- Size `20px x 20px`, `6px` radius for checkboxes, full circle for radios.
- Unchecked: `1.5px solid #E2E8F0` with `#FFFFFF` fill.
- Checked: Fill `#0B4EA2` with a `#FFFFFF` check/dot.

### Domain-Specific Components
- **Transfer Route Timeline:** Vertical or horizontal path visualizer with solid `#0B4EA2` line, airport icon indicator, estimated travel duration badge (`#EAF4FF`), and toll/highway inclusion labels.
- **VIP Airport Greeting Badge:** Highlight badge featuring flight tracking sync, terminal meet & greet, and luggage assistance in Emerald `#10B981` typography and subtle tint background.