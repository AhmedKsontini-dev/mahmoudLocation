-- =========================================================
-- BASE DE DONNEES - TUNISIA TRAVEL & MOBILITY
-- Location de voitures / Transferts / Excursions
-- =========================================================

-- ============================
-- 1. UTILISATEURS
-- ============================
CREATE TABLE users (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    first_name          VARCHAR(100) NOT NULL,
    last_name           VARCHAR(100) NOT NULL,
    email               VARCHAR(150) UNIQUE,
    phone               VARCHAR(30),
    whatsapp_number     VARCHAR(30),
    password_hash       VARCHAR(255),
    preferred_language  VARCHAR(5) DEFAULT 'fr',
    preferred_currency  VARCHAR(5) DEFAULT 'DT',
    is_guest            BOOLEAN DEFAULT FALSE,
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================
-- 2. DESTINATIONS (transverse : sert aux excursions ET aux mises en avant homepage)
-- ============================
CREATE TABLE destinations (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,          -- ex: "Sidi Bou Said"
    slug            VARCHAR(150) UNIQUE NOT NULL,
    region          VARCHAR(150),                   -- ex: "Tunis & Sidi Bou Said"
    description     TEXT,
    cover_image_url VARCHAR(255),
    is_featured     BOOLEAN DEFAULT FALSE           -- pour "Nos destinations phares"
);

-- ============================
-- 3. LOCATION DE VOITURES
-- ============================
CREATE TABLE rental_vehicles (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    brand               VARCHAR(100) NOT NULL,       -- ex: Peugeot
    model               VARCHAR(100) NOT NULL,       -- ex: 208
    category            VARCHAR(50),                 -- Economique, Compacte, SUV, 4x4...
    seats               INT DEFAULT 5,
    doors               INT DEFAULT 5,
    transmission        VARCHAR(20),                 -- Manuelle / Automatique
    air_conditioning    BOOLEAN DEFAULT TRUE,
    luggage_capacity    INT,
    year                INT,
    plate_number        VARCHAR(20),
    price_per_day       DECIMAL(10,2) NOT NULL,
    currency            VARCHAR(5) DEFAULT 'DT',
    status              VARCHAR(20) DEFAULT 'available', -- available / rented / maintenance
    image_url           VARCHAR(255)
);

CREATE TABLE car_rental_bookings (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NOT NULL,
    rental_vehicle_id   INT NOT NULL,
    pickup_date         DATE NOT NULL,
    return_date         DATE NOT NULL,
    pickup_location     VARCHAR(255),
    return_location     VARCHAR(255),
    total_price         DECIMAL(10,2) NOT NULL,
    currency            VARCHAR(5) DEFAULT 'DT',
    status              VARCHAR(20) DEFAULT 'pending', -- pending/confirmed/cancelled/completed
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (rental_vehicle_id) REFERENCES rental_vehicles(id)
);

-- ============================
-- 4. TRANSFERTS
-- ============================
CREATE TABLE transfer_routes (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    departure_label         VARCHAR(255) NOT NULL,   -- ex: "Sousse (Zone Hoteliere)"
    arrival_label           VARCHAR(255) NOT NULL,   -- ex: "Aeroport Tunis-Carthage (TUN)"
    transfer_type           VARCHAR(30) NOT NULL,    -- aeroport_hotel / hotel_aeroport / inter_villes
    distance_km             DECIMAL(6,2),
    duration_estimate_min   INT,
    base_price              DECIMAL(10,2) NOT NULL,
    currency                VARCHAR(5) DEFAULT 'DT'
);

CREATE TABLE transfer_vehicle_classes (
    id                          INT AUTO_INCREMENT PRIMARY KEY,
    name                        VARCHAR(100) NOT NULL,  -- Berline Compacte Eco, Grande Berline Executive, Minivan VIP
    description                 VARCHAR(255),
    seat_capacity               INT,
    luggage_capacity            INT,
    base_price_per_transfer     DECIMAL(10,2),
    is_recommended              BOOLEAN DEFAULT FALSE,
    image_url                   VARCHAR(255)
);

CREATE TABLE transfer_bookings (
    id                          INT AUTO_INCREMENT PRIMARY KEY,
    user_id                     INT,
    route_id                    INT NOT NULL,
    transfer_vehicle_class_id   INT NOT NULL,
    pickup_datetime             DATETIME NOT NULL,
    adults                      INT DEFAULT 1,
    children                    INT DEFAULT 0,
    luggage_standard            INT DEFAULT 0,
    luggage_cabin               INT DEFAULT 0,
    baby_seats                  INT DEFAULT 0,
    flight_number               VARCHAR(20),
    airline                     VARCHAR(100),
    flight_datetime             DATETIME,
    terminal                    VARCHAR(50),
    contact_full_name           VARCHAR(150) NOT NULL,
    contact_phone               VARCHAR(30) NOT NULL,
    contact_email                VARCHAR(150),
    preferred_contact_channel   VARCHAR(20) DEFAULT 'whatsapp', -- whatsapp/call/sms_email
    special_instructions        TEXT,
    total_price                 DECIMAL(10,2) NOT NULL,
    currency                    VARCHAR(5) DEFAULT 'DT',
    status                       VARCHAR(20) DEFAULT 'pending',
    created_at                   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (route_id) REFERENCES transfer_routes(id),
    FOREIGN KEY (transfer_vehicle_class_id) REFERENCES transfer_vehicle_classes(id)
);

CREATE TABLE transfer_options (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,  -- Siege bebe, Accueil personnalise, Chauffeur bilingue, Attente prolongee
    description     VARCHAR(255),
    price           DECIMAL(10,2) NOT NULL,
    price_unit      VARCHAR(20) DEFAULT 'fixed' -- fixed / per_hour
);

CREATE TABLE transfer_booking_options (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    transfer_booking_id    INT NOT NULL,
    transfer_option_id     INT NOT NULL,
    quantity                INT DEFAULT 1,
    price_applied           DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (transfer_booking_id) REFERENCES transfer_bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (transfer_option_id) REFERENCES transfer_options(id)
);

-- ============================
-- 5. EXCURSIONS
-- ============================
CREATE TABLE excursions (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    destination_id      INT NOT NULL,
    title               VARCHAR(200) NOT NULL,        -- ex: "Sidi Bou Said & Carthage Antique"
    slug                VARCHAR(200) UNIQUE NOT NULL,
    category            VARCHAR(50),                  -- Culture&Histoire, Desert&Aventure, Plage&Detente...
    badge               VARCHAR(50),                  -- Populaire, Meilleure vente, Aventure&Bivouac, Patrimoine UNESCO
    duration_type       VARCHAR(20),                  -- half_day / one_day / multi_day
    duration_days       INT DEFAULT 1,
    duration_label      VARCHAR(100),                 -- ex: "1 Journee (8h30-17h)"
    is_private          BOOLEAN DEFAULT FALSE,         -- excursion privee & guide vs petit groupe
    is_small_group      BOOLEAN DEFAULT FALSE,
    min_participants    INT DEFAULT 1,
    max_participants    INT,
    price_per_person    DECIMAL(10,2) NOT NULL,
    currency            VARCHAR(5) DEFAULT 'DT',
    price_eur_estimate  DECIMAL(10,2),
    short_description   VARCHAR(500),
    long_description    TEXT,
    meeting_point        VARCHAR(255),
    transport_type      VARCHAR(100),                  -- Prive & Climatise
    rating_avg          DECIMAL(2,1) DEFAULT 0,
    review_count        INT DEFAULT 0,
    cover_image_url      VARCHAR(255),
    status               VARCHAR(20) DEFAULT 'active',  -- active/draft/archived
    created_at           DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (destination_id) REFERENCES destinations(id)
);

CREATE TABLE excursion_itinerary_steps (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    excursion_id    INT NOT NULL,
    step_order      INT NOT NULL,
    time_label      VARCHAR(20),      -- ex: "08:30"
    title           VARCHAR(200) NOT NULL,
    description     TEXT,
    FOREIGN KEY (excursion_id) REFERENCES excursions(id) ON DELETE CASCADE
);

CREATE TABLE excursion_highlights (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    excursion_id    INT NOT NULL,
    icon            VARCHAR(50),
    label           VARCHAR(150) NOT NULL,   -- ex: "Panorama Golfe"
    FOREIGN KEY (excursion_id) REFERENCES excursions(id) ON DELETE CASCADE
);

CREATE TABLE excursion_inclusions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    excursion_id    INT NOT NULL,
    item_label      VARCHAR(255) NOT NULL,
    is_included     BOOLEAN NOT NULL,   -- TRUE = Inclus, FALSE = Non inclus
    FOREIGN KEY (excursion_id) REFERENCES excursions(id) ON DELETE CASCADE
);

CREATE TABLE excursion_gallery_images (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    excursion_id    INT NOT NULL,
    image_url       VARCHAR(255) NOT NULL,
    caption         VARCHAR(150),
    sort_order      INT DEFAULT 0,
    FOREIGN KEY (excursion_id) REFERENCES excursions(id) ON DELETE CASCADE
);

CREATE TABLE excursion_bookings (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    excursion_id        INT NOT NULL,
    user_id             INT,
    excursion_date      DATE NOT NULL,
    adults_count        INT DEFAULT 1,
    children_count      INT DEFAULT 0,
    pickup_region       VARCHAR(150),      -- ex: "Tunis Centre, Medina, Berges du Lac"
    pickup_address      VARCHAR(255),      -- ex: "Hotel Africa Tunis / Residence Gammarth"
    contact_full_name   VARCHAR(150) NOT NULL,
    contact_phone       VARCHAR(30) NOT NULL,
    contact_email       VARCHAR(150),
    total_price         DECIMAL(10,2) NOT NULL,
    currency            VARCHAR(5) DEFAULT 'DT',
    status              VARCHAR(20) DEFAULT 'pending',
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (excursion_id) REFERENCES excursions(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================
-- 6. AVIS (polymorphes : excursions, transferts, locations, ou avis generaux homepage)
-- ============================
CREATE TABLE reviews (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    reviewable_type         VARCHAR(30) NOT NULL,   -- 'excursion' / 'transfer' / 'rental' / 'general'
    reviewable_id           INT,                    -- NULL si avis general (homepage)
    user_id                 INT,
    reviewer_display_name   VARCHAR(150) NOT NULL,  -- ex: "Marc & Laura"
    reviewer_location       VARCHAR(150),           -- ex: "Paris"
    rating                  TINYINT NOT NULL,       -- 1 a 5
    comment                 TEXT,
    is_verified             BOOLEAN DEFAULT FALSE,
    created_at              DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================
-- 7. FAQ (reutilisable sur excursions, transferts, ou page generale)
-- ============================
CREATE TABLE faqs (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    reference_type  VARCHAR(30) NOT NULL,  -- 'excursion' / 'transfer' / 'rental' / 'general'
    reference_id    INT,                   -- NULL si FAQ generale
    question        VARCHAR(255) NOT NULL,
    answer          TEXT NOT NULL,
    sort_order      INT DEFAULT 0
);

-- ============================
-- 8. PAIEMENTS (transverse aux 3 types de reservation)
-- ============================
CREATE TABLE payments (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    booking_type            VARCHAR(20) NOT NULL,   -- 'car_rental' / 'transfer' / 'excursion'
    booking_id              INT NOT NULL,
    amount                  DECIMAL(10,2) NOT NULL,
    currency                VARCHAR(5) DEFAULT 'DT',
    payment_method          VARCHAR(30),            -- cash_on_site / card_on_site / online
    payment_status          VARCHAR(20) DEFAULT 'pending', -- pending/paid/refunded/failed
    transaction_reference   VARCHAR(100),
    paid_at                 DATETIME
);

-- =========================================================
-- INDEX RECOMMANDES
-- =========================================================
CREATE INDEX idx_car_rental_bookings_user ON car_rental_bookings(user_id);
CREATE INDEX idx_transfer_bookings_user ON transfer_bookings(user_id);
CREATE INDEX idx_excursion_bookings_user ON excursion_bookings(user_id);
CREATE INDEX idx_excursions_destination ON excursions(destination_id);
CREATE INDEX idx_reviews_reviewable ON reviews(reviewable_type, reviewable_id);
CREATE INDEX idx_faqs_reference ON faqs(reference_type, reference_id);
CREATE INDEX idx_payments_booking ON payments(booking_type, booking_id);
