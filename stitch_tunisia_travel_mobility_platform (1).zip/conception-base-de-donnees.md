# Conception de base de données — Tunisia Travel & Mobility

À partir de vos 4 captures d'écran, j'ai identifié **3 métiers principaux** sur le site :

1. **Location de voitures** (page d'accueil : Peugeot 208, Renault Clio, VW Golf, Dacia Duster...)
2. **Transferts** (aéroport ↔ hôtel, inter-villes, avec choix de véhicule, vol, options)
3. **Excursions & Circuits** (fiches détaillées avec itinéraire, inclusions, avis, réservation)

Plus des éléments transverses : **utilisateurs**, **destinations**, **avis clients**, **FAQ**, **paiements**.

Le fichier `erd.mermaid` contient le diagramme visuel complet. Le fichier `schema.sql` contient le script prêt à exécuter. Voici le détail et la logique de chaque table.

---

## 1. Utilisateurs — `users`

Un client peut réserver une voiture, un transfert et une excursion avec le même compte (ou en tant qu'invité, `is_guest`).

| Colonne | Rôle |
|---|---|
| id | Identifiant unique |
| first_name, last_name | Nom / prénom (vu dans le formulaire de contact) |
| email, phone, whatsapp_number | Coordonnées (le site privilégie WhatsApp) |
| preferred_language, preferred_currency | FR/EN/AR — DT/EUR/USD (sélecteurs visibles en haut du site) |

**Relation** : `1 user → N réservations` (voiture, transfert, excursion) et `1 user → N avis`.

---

## 2. Destinations — `destinations`

Correspond aux filtres et vignettes vues sur la page Excursions ("Tunis & Carthage", "Sidi Bou Saïd", "Sahara & Douz"...) et à la section "Nos destinations phares" de l'accueil.

**Relation** : `1 destination → N excursions`.

---

## 3. Location de voitures

### `rental_vehicles`
Le catalogue de véhicules ("Nos voitures populaires") : marque, modèle, catégorie, prix/jour, statut de disponibilité.

### `car_rental_bookings`
Une réservation = 1 utilisateur + 1 véhicule + dates de prise en charge/retour + lieux + prix total.

**Relation** : `1 rental_vehicle → N car_rental_bookings` (un même véhicule est réservé à des dates différentes).

---

## 4. Transferts

C'est le module le plus riche (page 4) :

### `transfer_routes`
Le trajet de base (ex: *Sousse (Zone Hôtelière) → Aéroport Tunis-Carthage*), son type (Aéroport→Hôtel / Hôtel→Aéroport / Inter-villes) et son tarif de base.

### `transfer_vehicle_classes`
Les 3 catégories vues dans le formulaire : *Berline Compacte Éco*, *Grande Berline Exécutive* (recommandée), *Minivan VIP*, chacune avec capacité et prix.

### `transfer_bookings`
La réservation complète : passagers, bagages, sièges bébé, infos de vol (numéro, compagnie, terminal — pour le "Suivi de vol en direct"), coordonnées du contact, canal préféré (WhatsApp/appel/SMS).

### `transfer_options` + `transfer_booking_options`
Les options additionnelles cochables (*Siège bébé*, *Accueil personnalisé*, *Chauffeur bilingue*, *Attente prolongée*) — relation **many-to-many** car une réservation peut cumuler plusieurs options, et chaque option peut être choisie sur plusieurs réservations. La table de jonction stocke aussi le prix appliqué au moment de la réservation (pour ne pas perdre l'historique si le tarif change plus tard).

**Relations** :
- `1 transfer_route → N transfer_bookings`
- `1 transfer_vehicle_class → N transfer_bookings`
- `N transfer_bookings ↔ N transfer_options` via `transfer_booking_options`

---

## 5. Excursions

Le module le plus détaillé (pages 2 et 3) :

### `excursions`
La fiche principale : titre, catégorie (Culture&Histoire, Désert&Aventure...), badge (Populaire, Meilleure vente...), durée, privé ou petit groupe, prix, note moyenne.

### `excursion_itinerary_steps`
Le programme horaire ("08:30 — Prise en charge", "09:30 — Visite de Carthage"...) — une table à part car c'est une liste ordonnée et de longueur variable selon l'excursion.

### `excursion_highlights`
Les vignettes "Ce que vous allez vivre" (Carthage & Byrsa, Sidi Bou Saïd, Panorama Golfe, Café des Délices).

### `excursion_inclusions`
Une seule table avec un booléen `is_included` pour gérer à la fois "Inclus dans le tarif" et "Non inclus" — évite de dupliquer la structure en deux tables.

### `excursion_gallery_images`
Les photos multiples de la fiche (photo principale + galerie "+4 photos").

### `excursion_bookings`
Le formulaire de réservation en 3 étapes vu sur la fiche (date/participants, lieu de prise en charge, coordonnées).

**Relations** : `1 destination → N excursions`, et `1 excursion → N` pour chacune de ses sous-tables (étapes, highlights, inclusions, photos, réservations).

---

## 6. Avis clients — `reviews`

Table **polymorphe** via `reviewable_type` (`excursion`, `transfer`, `rental`, ou `general` pour les témoignages libres de la page d'accueil) + `reviewable_id`. Cela évite de créer une table d'avis séparée pour chaque module, tout en gardant la possibilité de les distinguer.

## 7. FAQ — `faqs`

Même logique polymorphe (`reference_type` / `reference_id`) : réutilisable pour les questions fréquentes d'une excursion, d'un transfert, ou une FAQ générale du site.

## 8. Paiements — `payments`

Table transverse liée à n'importe quel type de réservation via `booking_type` + `booking_id`, pour centraliser le suivi (statut, méthode, référence de transaction) sans dupliquer la logique de paiement dans 3 tables différentes.

---

## Schéma relationnel — vue d'ensemble

```
users ─┬─< car_rental_bookings >─ rental_vehicles
       ├─< transfer_bookings   >─ transfer_routes
       │         │              └─ transfer_vehicle_classes
       │         └─< transfer_booking_options >─ transfer_options
       ├─< excursion_bookings  >─ excursions ─< destinations
       │                              ├─< excursion_itinerary_steps
       │                              ├─< excursion_highlights
       │                              ├─< excursion_inclusions
       │                              └─< excursion_gallery_images
       └─< reviews (polymorphe: excursion/transfer/rental/general)

faqs (polymorphe)         payments (polymorphe: sur les 3 types de réservation)
```

## Pourquoi ces choix de conception

- **3 tables de réservation distinctes** (`car_rental_bookings`, `transfer_bookings`, `excursion_bookings`) plutôt qu'une seule table générique : chaque métier a des champs très différents (vol pour les transferts, itinéraire pour les excursions, dates de restitution pour la location) — les regrouper aurait forcé énormément de colonnes vides.
- **`reviews` et `faqs` polymorphes** : ces deux éléments ont exactement la même structure quel que soit le module concerné, donc une seule table avec un discriminant (`reviewable_type`/`reference_type`) évite la duplication.
- **`payments` centralisée** : le suivi financier et les statuts de paiement sont identiques pour les 3 métiers, donc une seule table simplifie les rapports comptables globaux.
- **Vehicules séparés** (`rental_vehicles` vs `transfer_vehicle_classes`) : la logique tarifaire diffère (prix/jour pour la location, prix/trajet pour le transfert) et ce ne sont pas les mêmes véhicules dans votre flotte (Peugeot 208 à louer ≠ "Grande Berline Exécutive" pour transfert).

## Pour aller plus loin

Selon vos besoins réels, vous pourriez ajouter :
- `discount_codes` / `promotions` (codes promo appliqués aux réservations)
- `drivers` (chauffeurs assignés, liés à `transfer_bookings` et `car_rental_bookings`)
- `notifications_log` (SMS/WhatsApp envoyés pour chaque réservation)
- `admin_users` + `roles` (back-office de gestion)

Dites-moi si vous voulez que j'intègre l'un de ces éléments, ou que j'adapte le schéma pour un moteur précis (MySQL, PostgreSQL, Supabase...).
